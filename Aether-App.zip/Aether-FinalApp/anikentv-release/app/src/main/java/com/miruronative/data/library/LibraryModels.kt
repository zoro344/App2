package com.miruronative.data.library

import kotlinx.serialization.Serializable

/** One "continue watching" record per anime — the last episode watched + resume position. */
@Serializable
data class HistoryEntry(
    val anilistId: Int,
    val title: String,
    val cover: String?,
    val episodeNumber: Double,
    val episodeTitle: String? = null,
    val provider: String,
    val category: String,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val updatedAt: Long = 0,
) {
    val progressFraction: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    val episodeLabel: String
        get() = if (episodeNumber % 1.0 == 0.0) episodeNumber.toInt().toString() else episodeNumber.toString()
}

/** A saved series the user wants to watch. */
@Serializable
data class WatchlistEntry(
    val anilistId: Int,
    val title: String,
    val cover: String?,
    val format: String? = null,
    val averageScore: Int? = null,
    val addedAt: Long = 0,
)

internal fun mergeWatchlistEntries(
    local: List<WatchlistEntry>,
    fromAniList: List<WatchlistEntry>,
    addedAt: Long = System.currentTimeMillis(),
): List<WatchlistEntry> {
    if (fromAniList.isEmpty()) return local
    val remoteById = fromAniList.associateBy { it.anilistId }
    val localIds = local.mapTo(mutableSetOf()) { it.anilistId }
    return buildList {
        local.forEach { saved ->
            val remote = remoteById[saved.anilistId]
            add(remote?.copy(addedAt = saved.addedAt) ?: saved)
        }
        fromAniList.forEach { remote ->
            if (remote.anilistId !in localIds) add(remote.copy(addedAt = addedAt))
        }
    }.distinctBy { it.anilistId }
}
